% MATLAB script to plot gain curves for Half-Bridge CLLC Converter
% with different Quality Factors (Q)

% Normalized frequency range
f_normalized = linspace(0.5, 2.0, 500);

% Define different quality factors for comparison
Q_values = [0.5, 1.0, 2.0, 5.0];

% Plotting the gain curves for different Q values
figure;
hold on;
for Q = Q_values
    % Calculate gain for each frequency point
    gain = 1 ./ sqrt((1 - f_normalized.^2).^2 + (f_normalized / Q).^2);
    % Plot the gain curve
    plot(f_normalized, gain, 'DisplayName', ['Q = ' num2str(Q)]);
end

% Customize plot
xlabel('Normalized Frequency');
ylabel('Gain');
title('Gain Curves of Half-Bridge CLLC Converter with Different Quality Factors');
grid on;
legend;
hold off;